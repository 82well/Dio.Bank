using System.Reflection.Emit;
using System.Data;
using System;

     
namespace DIO.conta
{
    class Program
    {
        static void Main(string[] args)
        {
            Conta minhaConta = new Conta();
            minhaConta.Nome = "Wellington";

            
            Console.WriteLine("Ola");


        }
    }
}